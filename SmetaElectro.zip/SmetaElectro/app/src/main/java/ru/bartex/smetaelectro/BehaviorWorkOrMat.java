package ru.bartex.smetaelectro;

import android.content.Context;

public interface BehaviorWorkOrMat {
    void updateAdapter(Context context);
}